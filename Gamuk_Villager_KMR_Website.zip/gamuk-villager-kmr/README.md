# Gamuk — Stories from Kashmir

A responsive, static blog/news website starter with an Islamic and elegant visual style.

## Preview locally
Open `index.html` in a web browser. The website uses Google Fonts and image URLs, so an internet connection is needed for those assets.

## Publish free with GitHub Pages
1. Create or sign in to a GitHub account at https://github.com
2. Create a new **public** repository, for example `gamuk-villager-kmr`.
3. Upload `index.html` from this folder to the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. GitHub will provide a free address similar to `https://YOUR-USERNAME.github.io/gamuk-villager-kmr/`.

## Before publishing
- Replace the sample editorial cards with verified local stories and news.
- Add your contact email and social media links.
- Change the hero and article photos if you prefer your own photographs.
- The newsletter/contact form is a visual placeholder; it does not send messages yet. Connect a free form service or add a contact email to receive submissions.
- A custom `.com` domain usually costs money; the GitHub Pages address is free.

## Editing
Open `index.html` in a text editor. Search for the sample article titles and replace the text, image URLs, categories and metadata.
